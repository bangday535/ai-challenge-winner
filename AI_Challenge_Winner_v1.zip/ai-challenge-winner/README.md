# AI Challenge Winner v1.0

Private, self-hosted AI art competition studio built with Next.js.

## Included in v1

- Challenge brief form
- AI-generated three-concept battle (OpenAI Responses API)
- English image prompt output
- Image generation (OpenAI Images API)
- Vision-based artwork evaluation with weighted judging rubric
- Download generated PNG
- Basic HTTP authentication for private access
- API keys remain server-side

## Requirements

- Node.js 20.9+
- An OpenAI API key with API billing/credits and access to the selected models

## Run locally

1. Extract the ZIP.
2. Open a terminal in the project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env.local`.
5. Add your API key and set a strong private password.
6. Start the site:

   ```bash
   npm run dev
   ```

7. Open http://localhost:3000

The browser will ask for the username and password configured in `APP_USER` and `APP_PASSWORD`.

## Environment variables

- `OPENAI_API_KEY`: required
- `OPENAI_TEXT_MODEL`: defaults to `gpt-4.1`
- `OPENAI_IMAGE_MODEL`: defaults to `gpt-image-2.5-flare`
- `APP_USER`: private-site username
- `APP_PASSWORD`: private-site password

Check model availability and pricing in your provider account before generating. API usage is billed separately from a ChatGPT subscription.

## Security notes

- Never put API keys in `NEXT_PUBLIC_*` variables.
- Never commit `.env.local` to Git.
- Use a long unique password.
- For public deployment, add HTTPS, stronger session-based authentication, per-user rate limits, request-size limits, and persistent private object storage.
- The current v1 uses HTTP Basic Authentication as a simple personal-site gate. Do not expose it publicly without HTTPS.
- Generated images are held in browser memory until downloaded; v1 does not upload them to a third-party storage bucket.

## Current provider scope

OpenAI is wired end-to-end for concept generation, image generation, and visual evaluation.

Gemini and Replicate are documented as future provider adapters, not enabled in this starter. They can be added behind the same server-side provider interface without changing the dashboard.

## Important limitations

- The app is a functional starter, not a hosted service. You must install, configure, and run/deploy it.
- The default image model may require account eligibility or organization verification. If unavailable, set `OPENAI_IMAGE_MODEL` to another currently supported image model in your account.
- Aspect ratio is mapped to supported portrait, square, and landscape image sizes. 3:2 and 16:9 currently share the landscape size.
- AI judging is an estimate, not an objective prediction of the actual community vote.
