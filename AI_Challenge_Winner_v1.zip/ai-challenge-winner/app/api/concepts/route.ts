import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { theme, brief, mood, style, priority, criteria } = await req.json();
  if (!theme?.trim()) return NextResponse.json({ error: "Tema wajib diisi." }, { status: 400 });
  if (!process.env.OPENAI_API_KEY) return NextResponse.json({ error: "OPENAI_API_KEY belum diatur." }, { status: 503 });

  const model = process.env.OPENAI_TEXT_MODEL || "gpt-4.1";
  const prompt = `You are a strategic art director for image competitions. Create exactly 3 genuinely different, visually distinctive artwork concepts for this brief.
Theme: ${theme}
Rules/brief: ${brief || "No extra rules supplied"}
Visual style: ${style || "Choose the strongest style"}
Mood: ${mood || "Dramatic"}
Strategic priority: ${priority || "Balanced"}
Judging criteria: ${criteria || "Creativity, composition, detail, theme fit"}
For each concept provide: title, one-sentence hook, visual scene, composition, lighting/color palette, why it could score well, and a polished English image-generation prompt. Make the concepts specific and avoid generic clichés. Do not claim guaranteed wins.
Return valid JSON only: {"concepts":[{"title":"...","hook":"...","scene":"...","composition":"...","lighting":"...","advantage":"...","prompt":"..."}]}`;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model, input: prompt })
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data.error?.message || "Gagal membuat konsep." }, { status: response.status });
    const output = (data.output || []).flatMap((item: any) => item.content || []).map((part: any) => part.text || "").join("\n");
    const clean = output.replace(/^```json\s*/i, "").replace(/\s*```$/, "").trim();
    const parsed = JSON.parse(clean);
    return NextResponse.json(parsed);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Kesalahan server." }, { status: 500 });
  }
}
