import { NextRequest, NextResponse } from "next/server";

export const maxDuration = 120;

export async function POST(req: NextRequest) {
  const { prompt, aspectRatio, quality } = await req.json();
  if (!prompt?.trim()) return NextResponse.json({ error: "Prompt wajib diisi." }, { status: 400 });
  if (!process.env.OPENAI_API_KEY) return NextResponse.json({ error: "OPENAI_API_KEY belum diatur." }, { status: 503 });

  const size = aspectRatio === "4:5" ? "1024x1536" : aspectRatio === "16:9" ? "1536x1024" : aspectRatio === "3:2" ? "1536x1024" : "1024x1024";
  try {
    const response = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare",
        prompt,
        size,
        quality: quality || "high",
        output_format: "png",
        n: 1
      })
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data.error?.message || "Image generation gagal." }, { status: response.status });
    const b64 = data.data?.[0]?.b64_json;
    if (!b64) return NextResponse.json({ error: "Provider tidak mengembalikan gambar." }, { status: 502 });
    return NextResponse.json({ image: `data:image/png;base64,${b64}`, model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare" });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Kesalahan server." }, { status: 500 });
  }
}
