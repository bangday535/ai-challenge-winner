import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { image, theme, criteria, brief } = await req.json();
  if (!image?.startsWith("data:image/")) return NextResponse.json({ error: "Gambar tidak valid." }, { status: 400 });
  if (!process.env.OPENAI_API_KEY) return NextResponse.json({ error: "OPENAI_API_KEY belum diatur." }, { status: 503 });

  const model = process.env.OPENAI_TEXT_MODEL || "gpt-4.1";
  const instruction = `Act as a rigorous visual-art competition judge. Evaluate this submitted artwork against the challenge.
Theme: ${theme}
Rules/brief: ${brief || "No extra rules"}
Judging criteria: ${criteria || "Creativity, composition, detail, theme fit"}
Score exactly these categories from 0 to 100: originality (25% weight), theme_fit (25%), composition (20%), craft_detail (15%), emotional_impact (15%). Calculate weighted_total out of 100. Be honest and specific. Identify 3 strengths, 3 weaknesses, and 3 actionable improvements. Flag any possible mismatch with the brief. This is an estimate, not a prediction of actual judging.
Return valid JSON only: {"scores":{"originality":0,"theme_fit":0,"composition":0,"craft_detail":0,"emotional_impact":0,"weighted_total":0},"verdict":"...","strengths":["..."],"weaknesses":["..."],"improvements":["..."],"rule_check":"..."}`;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        input: [{ role: "user", content: [
          { type: "input_text", text: instruction },
          { type: "input_image", image_url: image, detail: "high" }
        ] }]
      })
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data.error?.message || "Evaluasi gagal." }, { status: response.status });
    const output = (data.output || []).flatMap((item: any) => item.content || []).map((part: any) => part.text || "").join("\n");
    const clean = output.replace(/^```json\s*/i, "").replace(/\s*```$/, "").trim();
    return NextResponse.json(JSON.parse(clean));
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Kesalahan server." }, { status: 500 });
  }
}
