 "use client";

import { useState } from "react";

type Concept = { title: string; hook: string; scene: string; composition: string; lighting: string; advantage: string; prompt: string };
type Evaluation = { scores: Record<string, number>; verdict: string; strengths: string[]; weaknesses: string[]; improvements: string[]; rule_check: string };

export default function Home() {
  const [theme, setTheme] = useState("Crash Team Racing (CTR)");
  const [brief, setBrief] = useState("Buat visual bertema Crash Team Racing. Mood dark & mysterious. Poster vertikal untuk kompetisi komunitas Facebook.");
  const [style, setStyle] = useState("AI chooses the strongest visual style");
  const [mood, setMood] = useState("Dark & Mysterious");
  const [ratio, setRatio] = useState("4:5");
  const [priority, setPriority] = useState("Balanced across all judging criteria");
  const [criteria, setCriteria] = useState("Creativity, composition, detail, and theme relevance");
  const [concepts, setConcepts] = useState<Concept[]>([]);
  const [selected, setSelected] = useState(0);
  const [image, setImage] = useState("");
  const [evaluation, setEvaluation] = useState<Evaluation | null>(null);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");

  async function callApi(path: string, body: unknown) {
    const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request gagal.");
    return data;
  }

  async function createConcepts() {
    setBusy("Menganalisis tema dan merancang konsep...");
    setError(""); setConcepts([]); setImage(""); setEvaluation(null);
    try {
      const data = await callApi("/api/concepts", { theme, brief, style, mood, priority, criteria });
      setConcepts(data.concepts || []);
      setSelected(0);
    } catch (e) { setError(e instanceof Error ? e.message : "Gagal."); }
    finally { setBusy(""); }
  }

  async function generate() {
    if (!concepts[selected]) return;
    setBusy("Mesin gambar sedang bekerja...");
    setError(""); setImage(""); setEvaluation(null);
    try {
      const prompt = `${concepts[selected].prompt}\n\nMood: ${mood}. Composition optimized for ${ratio} portrait/format. Competition-ready artwork, strong visual hierarchy, polished professional finish.`;
      const data = await callApi("/api/generate", { prompt, aspectRatio: ratio, quality: "high" });
      setImage(data.image);
    } catch (e) { setError(e instanceof Error ? e.message : "Gagal."); }
    finally { setBusy(""); }
  }

  async function evaluate() {
    if (!image) return;
    setBusy("Juri AI sedang memeriksa artwork...");
    setError("");
    try {
      const data = await callApi("/api/evaluate", { image, theme, criteria, brief });
      setEvaluation(data);
    } catch (e) { setError(e instanceof Error ? e.message : "Gagal."); }
    finally { setBusy(""); }
  }

  const scoreLabels: Record<string, string> = {
    originality: "Originalitas", theme_fit: "Kesesuaian tema", composition: "Komposisi",
    craft_detail: "Teknis & detail", emotional_impact: "Daya emosional"
  };

  return <main className="shell">
    <div className="topbar"><div className="brand">ACW / PRIVATE CREATIVE STUDIO</div><div className="muted">VERSION 1.0 · PERSONAL</div></div>
    <section className="hero">
      <div className="eyebrow">YOUR COMPETITION ART WORKFLOW</div>
      <h1>AI CHALLENGE<br/>WINNER.</h1>
      <p className="sub">Dari tema mentah menjadi konsep, prompt profesional, artwork, dan evaluasi juri AI. Satu studio, alur kerja lengkap.</p>
    </section>

    <div className="layout">
      <section className="panel">
        <h2>01 / Challenge Brief</h2>
        <label>Tema challenge</label><input value={theme} onChange={e=>setTheme(e.target.value)} placeholder="Masukkan tema challenge"/>
        <label>Deskripsi dan aturan</label><textarea value={brief} onChange={e=>setBrief(e.target.value)} placeholder="Brief, aturan, batasan, referensi..."/>
        <div className="row">
          <div><label>Gaya visual</label><select value={style} onChange={e=>setStyle(e.target.value)}><option>AI chooses the strongest visual style</option><option>Hyperrealistic / Photorealistic</option><option>Cinematic / Hollywood</option><option>Surrealism / Conceptual Art</option><option>Fantasy / Sci-Fi</option><option>3D Digital Art</option><option>Fine Art / Traditional Painting</option></select></div>
          <div><label>Mood</label><select value={mood} onChange={e=>setMood(e.target.value)}><option>Dark & Mysterious</option><option>Dramatic & Cinematic</option><option>Dreamlike & Magical</option><option>Epic & Grand</option><option>Emotional & Poetic</option><option>Minimalist & Elegant</option><option>Vibrant & Futuristic</option></select></div>
        </div>
        <div className="row">
          <div><label>Rasio</label><select value={ratio} onChange={e=>setRatio(e.target.value)}><option>4:5</option><option>1:1</option><option>3:2</option><option>16:9</option></select></div>
          <div><label>Prioritas</label><select value={priority} onChange={e=>setPriority(e.target.value)}><option>Balanced across all judging criteria</option><option>Originality and creativity</option><option>Visual impact and WOW factor</option><option>Storytelling and theme relevance</option></select></div>
        </div>
        <label>Kriteria juri</label><input value={criteria} onChange={e=>setCriteria(e.target.value)}/>
        <div className="actions"><button className="btn" onClick={createConcepts} disabled={!!busy || !theme.trim()}>✦ ANALYZE & CREATE CONCEPTS</button></div>
        <p className="muted">Konsep dan evaluasi memakai text/vision API. Pembuatan gambar memakai Images API. Penggunaan API dapat menimbulkan biaya.</p>
      </section>

      <section className="panel">
        <h2>02 / Concept Battle</h2>
        {concepts.length === 0 ? <p className="muted">Belum ada konsep. Isi brief lalu jalankan analisis untuk menghasilkan tiga arah kreatif yang berbeda.</p> :
          <div className="concepts">{concepts.map((c,i)=><button key={i} className={`concept ${selected===i?"active":""}`} onClick={()=>setSelected(i)}><strong>{i+1}. {c.title}</strong><span className="muted">{c.hook}</span></button>)}</div>}
        {concepts[selected] && <div className="output">
          <label>Konsep terpilih · {concepts[selected].title}</label>
          <p className="muted">{concepts[selected].scene}</p>
          <p className="muted"><b>Composition:</b> {concepts[selected].composition}</p>
          <p className="muted"><b>Lighting:</b> {concepts[selected].lighting}</p>
          <p className="muted"><b>Competitive edge:</b> {concepts[selected].advantage}</p>
          <label>Professional English prompt</label><pre>{concepts[selected].prompt}</pre>
          <div className="actions"><button className="btn" onClick={generate} disabled={!!busy}>✦ GENERATE ARTWORK</button><button className="btn secondary" onClick={()=>navigator.clipboard.writeText(concepts[selected].prompt)}>COPY PROMPT</button></div>
        </div>}
      </section>
    </div>

    <section className="panel output">
      <h2>03 / Artwork & AI Art Judge</h2>
      {image ? <><img className="art" src={image} alt="Generated competition artwork"/><div className="actions"><a className="btn" href={image} download="ai-challenge-winner.png">DOWNLOAD ARTWORK</a><button className="btn secondary" onClick={evaluate} disabled={!!busy}>✦ EVALUATE ARTWORK</button></div></> : <p className="muted">Artwork yang dihasilkan akan muncul di sini. Setelah itu jalankan AI Art Judge untuk mendapat penilaian dan saran perbaikan.</p>}
      {evaluation && <div className="output">
        <div className="eyebrow">AI JUDGE RESULT</div><div className="score">{evaluation.scores.weighted_total}/100</div><p>{evaluation.verdict}</p>
        {Object.entries(scoreLabels).map(([key,label])=><p className="muted" key={key}>{label}: <b>{evaluation.scores[key]}/100</b></p>)}
        <div className="row">
          <div><label>Strengths</label><ul>{evaluation.strengths?.map((x,i)=><li className="muted" key={i}>{x}</li>)}</ul></div>
          <div><label>Weaknesses</label><ul>{evaluation.weaknesses?.map((x,i)=><li className="muted" key={i}>{x}</li>)}</ul></div>
        </div>
        <label>Recommended improvements</label><ul>{evaluation.improvements?.map((x,i)=><li className="muted" key={i}>{x}</li>)}</ul>
        <p className="muted"><b>Rule check:</b> {evaluation.rule_check}</p>
      </div>}
    </section>
    <div className="status">{busy || (error ? `Error: ${error}` : "Ready. Your API keys stay on the server.")}</div>
    <p className="muted">AI scores are advisory, not a guarantee of competition results. Always check the community rules and image rights.</p>
  </main>;
}
