import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Challenge Winner",
  description: "Private AI art competition studio"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
